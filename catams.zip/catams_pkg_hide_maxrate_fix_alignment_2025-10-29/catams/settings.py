from pathlib import Path
import os
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'dev-secret'
DEBUG = True

CSRF_TRUSTED_ORIGINS = ['https://*.ngrok.io', 'https://*.ngrok-free.app', 'https://*.ngrok-free.dev']

ALLOWED_HOSTS = ['*', '127.0.0.1', 'localhost', '.ngrok.io', '.ngrok-free.app', '.ngrok-free.dev']

INSTALLED_APPS = [
    'django.contrib.admin','django.contrib.auth','django.contrib.contenttypes',
    'django.contrib.sessions','django.contrib.messages','django.contrib.staticfiles',
    'timesheets.apps.TimesheetsConfig',
    'bootnorm.apps.BootnormConfig',
    'messaging.apps.MessagingConfig',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'catams.urls'
TEMPLATES = [{
  'BACKEND':'django.template.backends.django.DjangoTemplates',
  'DIRS':[BASE_DIR/'templates'],
  'APP_DIRS':True,
  'OPTIONS':{'context_processors':[
    'django.template.context_processors.debug',
    'django.template.context_processors.request',
                'timesheets.context.ta_flags',
    'django.contrib.auth.context_processors.auth',
    'django.contrib.messages.context_processors.messages',
    'timesheets.context.role_flags',   # <-- add role flags globally
           # <-- add TA flag so TA Inbox appears
  ]}
}]
WSGI_APPLICATION='catams.wsgi.application'

DATABASES={'default':{'ENGINE':'django.db.backends.sqlite3','NAME':BASE_DIR/'db.sqlite3'}}
AUTH_PASSWORD_VALIDATORS=[]
LANGUAGE_CODE='en-us'
TIME_ZONE='UTC'
USE_I18N=True
USE_TZ=True
STATIC_URL='static/'
STATICFILES_DIRS=[BASE_DIR/'static']

FEATURE_CASUAL_APPLICATIONS=False

LOGIN_URL='/accounts/login/'
LOGIN_REDIRECT_URL='/portal/'
LOGOUT_REDIRECT_URL='/accounts/login/'

SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
USE_X_FORWARDED_HOST = True
